<?= $this->extend('layouts/templete/template'); ?>
<?= $this->section('Content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
    <h1>New Project</h1>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">

      <div class="col mb-3">
        <button type="button" class="btn btn-info" onclick="refresh()"><i class="bi bi-arrow-clockwise">REFRESH</i></button>
        <button type="button" class="btn btn-success" id="btnAccept"><i class="bi bi-box-arrow-down">ACCEPT</i></button>
        <button type="button" class="btn btn-danger" id="btnReject"><i class="bi bi-x-lg">REJECT</i></button>
      </div>

      <div class="cols-auto">
        <div class="card overflow-auto">
          <div class="card-body">
            <h5 class="card-title">Data New Projek</h5>

            <table id="tableNew" class="table datatable">
              <thead>
                <tr>
                  <th>ID Projek</th>
                  <th>Nama Depot</th>
                  <th>Judul</th>
                  <th>Kategori</th>
                  <th>Prioritas</th>
                  <th>Detail</th>
                </tr>
              </thead>
            </table>

          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- Detail Modal Request -->
  <div class="modal fade" id="detailRequest" data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="requestDetailLabel">Detail Request</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <label for="deskripsiRequest" class="form-label">Deskripsi</label>
              <textarea class="form-control" id="deskripsiRequest" style="height: 100px;" disabled></textarea>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Request -->

  <!-- Detail Modal Troubleshoot -->
  <div class="modal fade" id="detailTroubleshoot" data-bs-keyboard="false" tabindex="-1" aria-labelledby="troubleshootDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="troubleshootDetailLabel">Detail Troubleshoot</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <div class="col-12">
                <label for="waktu_error" class="form-label">Waktu Error</label>
                <input type="text" class="form-control" id="waktu_error" disabled>
              </div>
              <div class="col-12">
                <label for="fitur_error" class="form-label">Fitur Error</label>
                <input type="text" class="form-control" id="fitur_error" disabled>
              </div>
              <div class="col-12">
                <label for="gambar" class="form-label">Gambar</label>
                <div class="card" style="width: 18rem">
                  <img class="img-fluid" id="gambar" style="max-width: 1080; max-height: 1080;">
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Troubleshoot -->

  <!-- Modal Request -->
  <div class="modal fade" id="modalRequest" data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestLabel">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="requestLabel">Detail Request</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form class="row g-3 mt-1 mx-3 needs-validation" id="forminput" novalidate>
          <!-- <div class="col-12">
            <label for="idRequest" class="form-label">ID Projek</label>
            <input type="text" class="form-control " id="idRequest" disabled>
          </div> -->
          <div class="col-12">
            <label for="editJudulRequest" class="form-label">Judul</label>
            <input type="text" class="form-control " id="editJudulRequest" disabled>
          </div>
          <div class="col-12">
            <label for="editPrioritasRequest" class="form-label">Prioritas</label>
            <input type="text" class="form-control" id="editPrioritasRequest" disabled>
          </div>
          <div class="col-12">
            <label for="editKategoriRequest" class="form-label">Kategori</label>
            <input type="text" class="form-control" id="editKategoriRequest" disabled>
          </div>
          <div class="col-12">
            <label for="editDeskripsiRequest" class="form-label">Deskripsi</label>
            <textarea class="form-control" style="height: 100px" id="editDeskripsiRequest" disabled></textarea>
          </div>
          <div class="col-12">
            <label for="editTenggatRequest" class="form-label">Tenggat</label>
            <input type="date" autofocus class="form-control " id="editTenggatRequest" name="deadline">
          </div>
          <div class="col-12">
            <label for="editUserRequest" class="form-label">User</label>
            <select class="form-select" aria-label="Default select example" id="editUserRequest">
              <!-- ajax -->
            </select>
          </div>

          <div class="text-center mb-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="addRequest">Submit</button>
          </div>
        </form>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="xCloseRequest" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Modal Request -->

  <!-- Modal Troubleshoot -->
  <div class="modal fade" id="modalTroubleshoot" data-bs-keyboard="false" tabindex="-1" aria-labelledby="troubleshootLabel">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="troubleshootLabel">Trobleshoot Detail</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form class="row g-3 mt-1 mx-3 needs-validation" id="forminput" novalidate>
          <div class="col-12">
            <label for="editJudulTroubleshoot" class="form-label">Judul</label>
            <input type="text" class="form-control " id="editJudulTroubleshoot" disabled>
          </div>
          <div class="col-12">
            <label for="editPrioritasTroubleshoot" class="form-label">Prioritas</label>
            <input type="text" class="form-control" id="editPrioritasTroubleshoot" disabled>
          </div>
          <div class="col-12">
            <label for="editKategoriTroubleshoot" class="form-label">Kategori</label>
            <input type="text" class="form-control" id="editKategoriTroubleshoot" disabled>
          </div>
          <div class="col-12">
            <label for="editDeskripsiTroubleshoot" class="form-label">Deskripsi</label>
            <textarea class="form-control" style="height: 100px" id="editDeskripsiTroubleshoot" disabled></textarea>
          </div>
          <div class="col-12">
            <label for="editWaktuErrorTroubleshoot" class="form-label">Waktu Error</label>
            <textarea class="form-control" style="height: 100px" id="editWaktuErrorTroubleshoot" disabled></textarea>
          </div>
          <div class="col-12">
            <label for="editFiturErrorTroubleshoot" class="form-label">Fitur Error</label>
            <textarea class="form-control" style="height: 100px" id="editFiturErrorTroubleshoot" disabled></textarea>
          </div>
          <div class="col-12">
            <label for="editTenggatTroubleshoot" class="form-label">Tenggat</label>
            <input type="date" autofocus class="form-control " id="editTenggatTroubleshoot">
          </div>
          <div class="col-12">
            <label for="editUserTroubleshoot" class="form-label">User</label>
            <select class="form-select" aria-label="Default select example" id="editUserTroubleshoot">
              <!-- ajax -->
            </select>
          </div>

          <div class="text-center mb-3">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="addTroubleshoot">Submit</button>
          </div>
        </form>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="xCloseTroubleshoot">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Modal Troubleshoot -->
</main><!-- End #main -->

<?= $this->endSection(); ?>