<?= $this->extend('layouts/templete/template'); ?>
<?= $this->section('Content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
    <h1>History</h1>
    <!-- <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="">Home</a></li>
        <li class="breadcrumb-item active"><a href="/admin/history">History</a></li>
      </ol>
    </nav> -->
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="cols-auto">
        <div class="col mb-3">
          <button type="button" class="btn btn-info" onclick="refresh()"><i class="bi bi-arrow-clockwise">REFRESH</i></button>
        </div>
        <div class="card overflow-auto">
          <div class="card-body">
            <h5 class="card-title">History Rejected</h5>

            <!-- Default Table -->
            <table id="tableRejected" class="table datatable">
              <thead>
                <tr>
                  <th>ID Projek</th>
                  <th>Nama Depot</th>
                  <th>Judul</th>
                  <th>Status</th>
                  <th>Prioritas</th>
                  <th>Kategori</th>
                  <th>Tenggat</th>
                  <th>User</th>
                  <th>Details</th>
                </tr>
              </thead>

            </table>
            <!-- End Default Table Example -->
          </div>
        </div>
  </section>

  <!-- Detail Modal Request -->
  <div class="modal fade" id="detailRequest" data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="requestDetailLabel">Detail Request</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <label for="deskripsiRequest" class="form-label">Deskripsi</label>
              <textarea class="form-control" id="deskripsiRequest" style="height: 100px;" disabled></textarea>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Request -->

  <!-- Detail Modal Troubleshoot -->
  <div class="modal fade" id="detailTroubleshoot" data-bs-keyboard="false" tabindex="-1" aria-labelledby="troubleshootDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="troubleshootDetailLabel">Detail Troubleshoot</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <div class="col-12">
                <label for="waktu_error" class="form-label">Waktu Error</label>
                <input type="text" class="form-control" id="waktu_error" disabled>
              </div>
              <div class="col-12">
                <label for="fitur_error" class="form-label">Fitur Error</label>
                <input type="text" class="form-control" id="fitur_error" disabled>
              </div>
              <div class="col-12">
                <label for="gambar" class="form-label">Gambar</label>
                <div class="card" style="width: 18rem">
                  <img class="img-fluid" id="gambar" style="max-width: 1080; max-height: 1080;">
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Troubleshoot -->



</main><!-- End #main -->

<?= $this->endSection(); ?>