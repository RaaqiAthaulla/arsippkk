<?= $this->extend('layouts/templete/template'); ?>
<?= $this->section('Content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
    <h1>Pending</h1>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="col mb-3">
          <button type="button" class="btn btn-info" onclick="refresh()"><i class="bi bi-arrow-clockwise">REFRESH</i></button>
          <button type="button" class="btn btn-success" id="btnedit"><i class="bi bi-box-arrow-down"></i></button>
          <button type="button" class="btn btn-danger" id="btnReject"><i class="bi bi-x-lg"></i></button>
        </div>
        <div class="card overflow-auto">
          <div class="card-body">
            <h5 class="card-title">Pending</h5>

            <!-- Default Table -->
            <table id="tablePending" class="table datatable">
              <thead>
                <tr>
                  <th>ID Projek</th>
                  <th>ID Depot</th>
                  <th>Title</th>
                  <th>Status</th>
                  <th>Kategori</th>
                  <th>Prioritas</th>
                  <th>Tenggat</th>
                  <th>User</th>
                  <th>Details</th>
                </tr>
              </thead>
            </table>
            <!-- End Default Table Example -->
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- Detail Modal Request -->
  <div class="modal fade" id="detailRequest" data-bs-keyboard="false" tabindex="-1" aria-labelledby="requestDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="requestDetailLabel">Detail Request</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <label for="deskripsiRequest" class="form-label">Deskripsi</label>
              <textarea class="form-control" id="deskripsiRequest" style="height: 100px;" disabled></textarea>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Request -->

  <!-- Detail Modal Troubleshoot -->
  <div class="modal fade" id="detailTroubleshoot" data-bs-keyboard="false" tabindex="-1" aria-labelledby="troubleshootDetailLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="troubleshootDetailLabel">Detail Troubleshoot</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card">
            <div class="card-body">
              <div class="col-12">
                <label for="waktu_error" class="form-label">Waktu Error</label>
                <input type="text" class="form-control" id="waktu_error" disabled>
              </div>
              <div class="col-12">
                <label for="fitur_error" class="form-label">Fitur Error</label>
                <input type="text" class="form-control" id="fitur_error" disabled>
              </div>
              <div class="col-12">
                <label for="gambar" class="form-label">Gambar</label>
                <div class="card" style="width: 18rem">
                  <img class="img-fluid" id="gambar" style="max-width: 1080; max-height: 1080;">
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- End Detail Modal Troubleshoot -->


  <!-- Modal Request -->
  <div class="modal fade" id="modalRequest" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Request Detail</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" id="closeRequest" aria-label="Close"></button>
        </div>
        <!-- Vertical Form -->
        <form class="row g-3 mt-1 mx-3 needs-validation" id="forminput" novalidate>
          <div class="col-12">
            <label for="judulRequest" class="form-label" id="">Judul</label>
            <input type="text" autofocus class="form-control " id="editJudul" name="judul" disabled>
          </div>
          <div class="col-12">
            <label for="kategori" class="form-label" id="">Kategori</label>
            <input type="text" class="form-control" id="editKategoriRequest" name="kategori" disabled>
          </div>
          <div class="col-12">
            <label for="deadline" class="form-label" id="">Tenggat</label>
            <input type="date" autofocus class="form-control " id="editTenggat" name="deadline">
          </div>
          <div class="col-12">
            <label for="status" class="form-label" id="">Status</label>
            <input type="text" class="form-control" id="editStatus" name="status" disabled>
            <input type="hidden" class="form-control" id="newStatusRequest" name="status" value="pending" disabled>
          </div>
          <div class="col-12">
            <label for="Prioritas" class="form-label" id="">Prioritas</label>
            <input type="text" class="form-control" id="editPrioritas" name="status" disabled>
          </div>
          <div class="col-12">
            <label for="User" class="form-label" id="">User</label>
            <div class="col-sm-10">
              <select class="form-select" aria-label="Default select example" id="userRequest" name="user">

              </select>
            </div>
          </div>
          <div class="col-12">
            <label for="deskripsi" class="form-label" id="">Deskripsi</label>
            <textarea class="form-control" style="height: 100px" id="editDeskripsi" name="deskripsi" disabled></textarea>
          </div>


          <div class="text-center mb-3">
            <button type="button" class="btn btn-primary" id="addRequest">Submit</button>
            <button type="reset" class="btn btn-secondary">Reset</button>
          </div>
        </form><!-- Vertical Form -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="xCloseRequest" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Troubleshoot -->
  <div class="modal fade" id="modalTroubleshoot" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Trobleshoot Detail</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" id="closeTroubleshoot" aria-label="Close"></button>
        </div>
        <!-- Vertical Form -->
        <form class="row g-3 mt-1 mx-3 needs-validation" id="forminput" novalidate>
          <div class="col-12">
            <label for="judulRequest" class="form-label" id="">Judul</label>
            <input type="text" autofocus class="form-control " id="judulTroubleshoot" name="judul" disabled>
          </div>
          <div class="col-12">
            <label for="kategori" class="form-label" id="">Kategori</label>
            <input type="text" class="form-control" id="editKategoriTroubleshoot" name="kategori" disabled>
          </div>
          <div class="col-12">
            <label for="deadline" class="form-label" id="">Tenggat</label>
            <input type="date" autofocus class="form-control " id="tenggatTroubleshoot" name="deadline">
          </div>
          <div class="col-12">
            <label for="status" class="form-label" id="">Status</label>
            <input type="text" class="form-control" id="statusTroubleshoot" name="status" disabled>
            <input type="hidden" class="form-control" id="newStatusTroubleshoot" name="status" value="pending" disabled>
            <div class="col-12">
              <label for="Prioritas" class="form-label" id="">Prioritas</label>
              <input type="text" class="form-control" id="prioritasTroubleshoot" name="status" disabled>
            </div>
            <div class="col-12">
              <label for="User" class="form-label" id="">User</label>
              <div class="col-sm-10">
                <select class="form-select" aria-label="Default select example" id="userTroubleshoot" name="user">
                </select>
              </div>
            </div>
            <div class="col-12">
              <label for="Prioritas" class="form-label" id="">Waktu Error</label>
              <input type="text" class="form-control" id="editWaktu_error" name="status" value="" disabled>
            </div>
            <div class="col-12">
              <label for="Prioritas" class="form-label" id="">Fitur Error</label>
              <input type="text" class="form-control" id="editFitur_error" name="status" disabled>
            </div>
            <div class="text-center mb-3">
              <button type="button" class="btn btn-primary" id="addTroubleshoot">Submit</button>
              <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
        </form><!-- Vertical Form -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="xCloseTroubleshoot">Close</button>
        </div>
      </div>
    </div>
  </div>
</main><!-- End #main -->

<?= $this->endSection(); ?>